tar.xz fixture
